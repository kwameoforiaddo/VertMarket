﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VertMarketMagazineAPIConsumer
{
    public class MagazineBrand
    {
        //public int MagazineBrandId { get; set; }
        private string MagazineBrandName { get; set; }

        public Magazine MagazineId { get; set; }

    }
}
