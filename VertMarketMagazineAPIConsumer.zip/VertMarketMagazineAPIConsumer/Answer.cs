﻿using Newtonsoft.Json;

namespace VertMarketMagazineAPIConsumer
{


    class dataAns
    {


        public List<Answer> answers { get; set; }

        internal class Answer
        {
            // public string category { get; set; }
            [JsonProperty("id")]
            public string subscriptionId { get; set; }

            //public int count { get; set; }
        }
    }
}