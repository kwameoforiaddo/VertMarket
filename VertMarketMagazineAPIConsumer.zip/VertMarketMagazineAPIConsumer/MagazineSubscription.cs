﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VertMarketMagazineAPIConsumer
{
    public class MagazineSubscription
    {

        [JsonProperty("id")]
        public string id { get; set; }
        //public MagazineCategory CategoryId { get; set; }

        [JsonProperty("magazineIds")]
        public int[]? magazineIds { get; set; }

        

        [JsonProperty("firstName")]
        public string? firstName { get; set; }

        [JsonProperty("lastName")]
        public string? lastName { get; set; }
        
    }
}
