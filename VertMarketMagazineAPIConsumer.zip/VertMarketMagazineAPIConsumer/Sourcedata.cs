﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;
using Newtonsoft.Json;
using System.Text.Json;
using System.Text.Json.Serialization;
using Newtonsoft.Json.Linq;
using static VertMarketMagazineAPIConsumer.Sourcedata;

namespace VertMarketMagazineAPIConsumer
{
    public class Sourcedata
    {
        [JsonProperty("data")]
        //public Dictionary<int,MagazineSubscription> data { get; set; }
        public MagazineSubscription[] data { get; set; }

    }
}
