﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VertMarketMagazineAPIConsumer
{
    public  class SilentAppTokenObj
    {
        public bool isSuccess;
        public  string  token {  get; set; }

        //public   int tokenDetailThree { get; set; }
    }
}
