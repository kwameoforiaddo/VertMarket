﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;
using Newtonsoft.Json;
using System.Text.Json;
using System.Text.Json.Serialization;
using Newtonsoft.Json.Linq;
using static VertMarketMagazineAPIConsumer.Sourcedata;

namespace VertMarketMagazineAPIConsumer
{
    class APIRequestsGateway
    {
        //Get request to acquire access token (httpclient and/or ItokenAcquisionAsync from msal )

        //Create methods for all endpoint calls in swagger
        //PUll ids first and consider pagination
        //Research on optimal request headers needed 
        //Use linq query if suitable 

        //Explore Serialization and deserialization objects
        // Explore System.Net library for the http requests. 
        // Implement Dependency injection
        // Refresh on where static classes are suitable. 
        // Try Catch handle all possible exceptions
        // Refresh on overcoming throttling, intermittent requests and timeouts, 503s etc
        // Refresh on reducing latency of API calls. 


        //---- Question---

        /* identify all subscribers that are subscribed to at least one magazine in each
        category*/
        private static HttpClient httpClient;
        //string _baseUri = "http://magazinestore.azurewebsites.net/";
        //Uri tokenUri = new Uri();

        SilentAppTokenObj? magAccessToken;
        internal static string vertMktToken;
        //MagazineCategory? category;

        //static MagazineCategories;

        //implementing Task Pattern for asynchronous calls 
        // other patterns could be event based or asychronous methods patterns

        //avoid port exhaustion, reason for Dependency Injection. 
        public async Task<SilentAppTokenObj> RequestAccessToken()
        {
            httpClient = new HttpClient();
            httpClient.BaseAddress = new Uri("http://magazinestore.azurewebsites.net/");
            httpClient.DefaultRequestHeaders.Accept.Clear();
            httpClient.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
            httpClient.DefaultRequestHeaders.Add("User-Agent", "KwameAddoDesktop");

            try
            {

                var responseTokenMessage = await httpClient.GetStringAsync(httpClient.BaseAddress + "/api//token");
                Console.WriteLine(responseTokenMessage);

                magAccessToken = JsonConvert.DeserializeObject<SilentAppTokenObj>(responseTokenMessage);





                vertMktToken = magAccessToken.token;
                Console.WriteLine(vertMktToken);


            } catch (Exception ex)
            {
                throw new Exception(ex.Message);


            }
            return magAccessToken;









        }


        public MagazineCategory magazineCategory = new MagazineCategory();
        public Sourcedata subscriptionList = new Sourcedata();
        public Subscriptions subscriptions = new Subscriptions();
        public Sourcedata? dataDSubscriberList = new Sourcedata();



       

        public async Task<MagazineCategory> GetCategories()
        {

            string accessToken = vertMktToken;
            httpClient.DefaultRequestHeaders.Accept.Clear();
            httpClient.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
            httpClient.DefaultRequestHeaders.Add("User-Agent", "KwameAddoDesktop");

            try
            {
                var results = await httpClient.GetStringAsync(httpClient.BaseAddress + "/api/categories/" + accessToken);

                CatSourceData? catResults = JsonConvert.DeserializeObject<CatSourceData>(results);


                magazineCategory.categories = catResults.data;


                Console.WriteLine("--------------------");
                Console.WriteLine(results);

            } catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            return magazineCategory; // array of magazine categories, news, science,etc
        }

        public async Task<Sourcedata> GetListOfSubscribers()
        {


            string accessToken = vertMktToken;
            httpClient.DefaultRequestHeaders.Accept.Clear();
            httpClient.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
            httpClient.DefaultRequestHeaders.Add("User-Agent", "KwameAddoDesktop");

            try
            {
                var results = await httpClient.GetStringAsync(httpClient.BaseAddress + "/api/subscribers/" + accessToken);

                dataDSubscriberList = JsonConvert.DeserializeObject<Sourcedata>(results);

                Console.WriteLine(results);
                Console.WriteLine(subscriptionList);
                //Console.ReadKey();



                //
                //ParseJSON(results);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            return dataDSubscriberList;  // holds deserialized subscriptions with their corresponding user and array of magazines. 

        }





        


        string? magcategory;

        MagPerCatSourceData? dataMagPerCategory = new MagPerCatSourceData();

        Dictionary<string, MagazineSubscription> magListPerCatSortedPerCat = new Dictionary<string, MagazineSubscription>();

        Dictionary<string, int[]> aCategoryMagazineIds = new Dictionary<string, int[]>();


        public async Task<MagPerCatSourceData> GetMagazinesForSpecifiedCategory()
        {
            string accessToken = vertMktToken;
            foreach (var item in magazineCategory.categories)
            {
                try
                {
                    magcategory = item.ToLower();

                    var results = await httpClient.GetStringAsync(httpClient.BaseAddress + "/api/magazines/" + accessToken + "/" + magcategory);
                    var dataMagsPerCat = results;
                    Console.WriteLine(dataMagsPerCat);

                    dataMagPerCategory = JsonConvert.DeserializeObject<MagPerCatSourceData>(results);
                    Console.WriteLine("--------------------");

                    Console.WriteLine("these are magazineids sorted by category...");
                    Console.WriteLine(results);
                    Console.WriteLine("--------------------");
                    Console.WriteLine("--------------------");



                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);

                }

              

              //  magListPerCatSortedPerCat.Add(magcategory, dataMagPerCategory); //the magazineIds etc, currently a particular selected category/ capture single id


                // filterAnswer(magListPerCatSortedPerCat, dataDSubscriberList);


            }

            return dataMagPerCategory;// use id(single id only) from dataMagPerCategory to search into subscriber list magazine array of magazine ids.(array of ids) 

            // intersect in linq

            //does subscriberlist.data.magazine.contain dataMagPerCategory.data.id, if so found, save subscriber id
        }


        

        Dictionary<string, string[]> final = new Dictionary<string, string[]>();
        List <string> postAnswerList = new List<string>();

        List<string> replaceMagIdByCat = new List<string>();



        public void  getCatMagIdTable()
        {
            int size = dataMagPerCategory.data.Count;

            //int[] magIdsForACat = new int[size];
            //int i = 0;
            foreach (var item in dataMagPerCategory.data)
            {
                bool found = false;
                var  category = item.category;
                var  magIdForACategory = item.id;
                int counter=0;

                
                
               // catMagIdsDictionary.Add(item.category, item.id);
                int aSize = -1;

                foreach(var item2 in dataDSubscriberList.data)
                {
                   //int counter = 0;
                    
                   for(int i = 0; i < item2.magazineIds.Length; )
                    {
                        if (item2.magazineIds[i] == magIdForACategory)
                        {
                            found = true;
                            //counter++; // reset after array fills
                        }
                        i++;
                        if (found) 
                        {
                            replaceMagIdByCat.Add(category);
                        
                        }

                        
                    }

                    if (!final.ContainsKey(item2.id))
                    {
                        final.Add(item2.id.ToString(), replaceMagIdByCat.Distinct().ToArray());

                    }


                 // aSize =  replaceMagIdByCat.Capacity;




                }



                foreach( var fv in final.Keys)
                {
                    Console.WriteLine(fv.ToString());
                    postAnswerList.Add(fv.ToString());
                    
                    
                    
                    
                    Console.ReadKey();
                }






                //foreach( string  fV in final)
                //{
                //    //if(fV.Value.Length >= aSize)
                //    //{
                //    //    final2.Add(fV.Key);
                //    //}

                //    final2.Add(string.Format(fV.Key.ToString()));
                //    Console.WriteLine(string.Format(final2.ToString()));
                //    
                    
                //}
            
             


            }


            



            // subscMagIdsDictionary.Add(item2.id, item2.magazineIds.ToList());

            //if(item2.magazineIds.Contains(item.id)) 
            //{
            //     found = true;
            //    // converting magazine id into its category array. 

            //}



        }






        public async Task PostAnswer()
        {


            string accessToken = vertMktToken;
            httpClient.DefaultRequestHeaders.Accept.Clear();
            httpClient.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
            httpClient.DefaultRequestHeaders.Add("User-Agent", "KwameAddoDesktop");




            try
            {

                var serialAnswer = JsonConvert.SerializeObject(postAnswerList.ToString());
                var strAnswer = new StringContent(serialAnswer, Encoding.UTF8, "application/json");

                var answer = await httpClient.PostAsync(httpClient.BaseAddress + "/api/answer/" + accessToken, strAnswer);




                Console.WriteLine(answer.ToString());



            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            // array of magazine categories, news, science,etc
        }






        //public void getmagazineIdsPerCategory() 
        //{
        //    int size = dataMagPerCategory.data.Count;
        //    int[] magIdsForACat = new int[size];

        //   foreach(var item in dataMagPerCategory.data)
        //   {
        //        category.Add(item.category);
        //        for(int i = 0; i < dataMagPerCategory.data.Count; i++)
        //        {
        //            magIdsForACat[i] = item.id;
        //            break;
        //        }
        //        if (!category.Contains(item.category))
        //        {
        //            //category.Add(item.category);
        //            catMagIdsDictionary.Add(magIdsForACat, item.category );
        //        }
        //   }


        //    //convert to an dictionary of category and its magazineid 

        //}



        //public void getSubscIdMagIds()
        //{
        //    int size = subscriptionList.data.Length-1;
        //    int[] magIdsForACat = new int[size];

        //    foreach (var item in subscriptionList.data)
        //    {
        //        subscMagIdsDictionary.Add(item.magazineIds,item.id);
        //    }


        //}









        //public void filterAnswer(Dictionary<int[],string> subscMagIds, Dictionary<int[], string> catMagIds)
        //{



        //from kvp1 in catMagIds
        //join kvp2 in subscMagIds on kvp1.Value as  kvp2.Key
        //select new { key = kvp1.Key, value1 = kvp1.Value, value2 = kvp2.Value }


        //int size = subscMagIds.Count;

        //Dictionary<int[],string> catCount = new Dictionary<int[], string>();

        //  var answer = from sub in subscMagIds join catId in catMagIds on sub.Key equals catId.Key;



        //var finalDictionary = subscMagIds
        //             .ToLookup(sub => sub.Key)
        //             .Contains(catMagIds.ToLookup(cat => cat.Key)
        //            // .GroupBy(sub => sub.Key, sub => sub.Select(cat => cat.Value));

        //             //.ToDictionary(z => z.Key, z => z.SelectMany(y => y.SelectMany(u => u)).Distinct().ToList());























        //string subscriberId;
        // string category;

        //foreach (KeyValuePair<string, int[]> item in subscMagIds)
        //{
        //    subscriberId = item.Key;

        //    foreach (KeyValuePair <string,int[]> item2 in catMagIds)
        //    {
        //      category = item2.Key;
        //      counter =  item.Value.Intersect(item2.Value).Count();


        //       // diff = item.Value.Length - counter;
        //    em1.Add(subscriberId); em2.Add(category);em3.Add(counter);


        //    }

        //}

        //answerPost(em1, em2, em3);

        //}
        //Tuple<string, string, int> ansTuple




        //public void answerPost(List<string> s, List<string> cat, List<int> count )
        //{




        //}



        #region v1 vault

        /*data structure buggy*/


        //public async Task<Subscriptions> GetListOfSubscribers()
        //{


        //   string accessToken = vertMktToken;
        //    httpClient.DefaultRequestHeaders.Accept.Clear();
        //    httpClient.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
        //    httpClient.DefaultRequestHeaders.Add("User-Agent", "KwameAddoDesktop");

        //    try
        //    {
        //        var results = await httpClient.GetStringAsync(httpClient.BaseAddress + "/api/subscribers/"+accessToken);

        //        Subscriptions? dataD = JsonConvert.DeserializeObject<Subscriptions>(results);












        //        Console.WriteLine(results);
        //        Console.WriteLine(subscriptionList);
        //        //Console.ReadKey();


        //        //
        //        //ParseJSON(results);
        //    }
        //    catch(Exception ex)
        //    {
        //        Console.WriteLine(ex.Message);
        //    }

        //    return subscriptions;
        //}

        //List<string> subscibeId = new List<string>();
        //List<int> subsMagIds = new List<int>();

        //Dictionary<string, IEnumerable<string>> kvp = new Dictionary<string, IEnumerable<string>>();

        // int size = dataMagPerCategory.magazineIds.Length;

        //int[] magIdsPerCat = new int[]; //datasource1




        //foreach (var item in dataDSubList.magazineIds)
        //{
        //    int i = 0;

        //    magIdsPerCat[i] = item;

        //    if ()
        //    {
        //        catMagIdsDictionary.Add(workCategory, magIdsPerCat);

        //    }
        //    else continue;
        //}
        // subscibeId.Add(subsId);




        //kvp.Add(subsId, subMagId);

        //subsMagIds.Add(subMagId);






        //foreach (var pair in subscMagIdsDictionary) //unified and sorted by category name
        //

        //    string skey = pair.Key;
        //    int[] values = pair.Value;



        //    var MS = catMagIdsDictionary.Intersect(subscMagIdsDictionary).ToList();
        //    // or 
        //    var QS = (from num in subscMagIdsDictionary
        //              select num)
        //              .Intersect(catMagIdsDictionary).ToList();


        //    foreach (var item in MS)
        //    {
        //        if(item.Value.Length >= 4)
        //        {

        //            answer.Add(item.Key);
        //        }
        //    }

        //    Console.WriteLine(answer);
        //    Console.ReadKey();





        //aCategoryMagazineIds.Add(skey, magIds);



        //foreach (var item in dataMagPerCategory.data)

        //{
        //    if (item.category != category) continue;

        //    var id = (from p in pair.Value select p.id).FirstOrDefault<int>(); //magazine ids for a specific category

        //    var subsc = (from s in dataDSubscriberList.data select s.id).FirstOrDefault<string>();
        //   // if(item.id.Equals(subsc)) continue;

        //    if ( id == item.id)
        //    {
        //        counter++;


        //    }

        //}






        //foreach(var kvp in finalAnswers)
        //{

        //    Console.WriteLine(kvp.Key);
        //}






        //public void answer(List<dynamic> magPerCategoryList)
        //{
        //    List<string> passedSubscriptionCheckId = null;
        //    string[] categories = magazineCategory.categories;




        //    foreach (var item in dataDSubscriberList.data)  // contains subscription id and list of magazines 
        //    {
        //        if (item.magazineIds.Length < magazineCategory.categories.Length)
        //        {

        //            continue; // items with magazineIds less than number of categories will not meet requirement. to be in all categories, magazineIds must be greater than or equal to categories count. 
        //        }
        //        else
        //        {

        //            passedSubscriptionCheckId.Add(item.id);

        //            int[] subscribedMagsIds = item.magazineIds;




        //            var myTuple = new Tuple<MagazineSubscription[], string[]>(dataDSubscriberList.data, magazineCategory.categories);
        //        }
        //    }




        //}


        //public void GetCurrentMagazineCategories( User UserId,string accessToken)
        //{


        //   var results = httpClient.GetAsync(accessToken).Result;

        //}

        //public  void MagazineListPerCategory( MagazineCategory categoryId, string accessToken)
        //{
        //    List<Magazine> magazines;

        //}


        /*
         * /api/categories/{token} - This endpoint will return our current magazine categories
           /api/magazines/{token}/{category} - This endpoint will return magazines for the
specified category

        a category will have 0 to N magazines (category and magazine will have an abstract relationship)

        a Magazine will have 0 to N magazineBrands

        a Magazine brand belongs to a particular Category. ( concrete )
        /
         
         */

        #endregion
        public string PrintMessage(string message)
        {
            return message;
        }

       
    }
}
