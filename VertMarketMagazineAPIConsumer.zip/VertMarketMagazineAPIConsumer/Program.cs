﻿// See https://aka.ms/new-console-template for more information
using VertMarketMagazineAPIConsumer;

Console.WriteLine("Requesting Token From VertMarketMagazine");


APIRequestsGateway apiRequests = new APIRequestsGateway();

 await apiRequests.RequestAccessToken();
 await apiRequests.GetListOfSubscribers();
 await apiRequests.GetCategories();
 await apiRequests.GetMagazinesForSpecifiedCategory();
 apiRequests.getCatMagIdTable();
 await apiRequests.PostAnswer();
 