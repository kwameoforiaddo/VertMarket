﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VertMarketMagazineAPIConsumer
{
    public class Magazine
    {
        
        public int id { get; set; }
        private List<String> Authors { get; set; }

       // public List<MagazineBrand> MagazineBrands { get; set; }
        private MagazineCategory? CategoryName { get; set; } 

    }
}
