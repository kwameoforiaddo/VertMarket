﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VertMarketMagazineAPIConsumer
{



    public class CatSourceData
    {
        [JsonProperty("data")]
        public string[] data { get; set; }

    }
    public class MagazineCategory
    {
            // public static int CategoryId { get; set; }


            public string[] categories { get; set; }




            //static IList<Magazine> MagazineId { get; set; } //iterator evaluate return sequence lazily. 

            //static List<Magazine> Magazines { get; set; }


            ///public static  List<Magazine> MagazineNamesList { get; set; }
    }
    
}
