﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VertMarketMagazineAPIConsumer
{
    public class Subscriptions
    {
        // public int  SubscriptionsCount { get; set; }
        //public IEnumerable<MagazineSubscription> subscriptions { get; set; } 

        public string token { get; set; }

        public bool isSuccess { get; set; }

        public Sourcedata[] subscriptionData { get; set;}


       

    }
}
