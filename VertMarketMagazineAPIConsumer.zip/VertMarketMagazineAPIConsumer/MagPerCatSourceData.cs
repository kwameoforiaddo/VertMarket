﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VertMarketMagazineAPIConsumer
{


    public class MagPerCatSourceData
    {
        [JsonProperty("data")]
        public List<MagazineCountPerCategory> data { get; set; }

        public class MagazineCountPerCategory
        {

            [JsonProperty("name")]
            public string name { get; set; }

            public string magName { get; set; }

            [JsonProperty("id")]
            public int id { get; set; }

            [JsonProperty("category")]
            public string category { get; set; }



        }

        
    }
}
